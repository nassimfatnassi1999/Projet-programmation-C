#include <gtk/gtk.h>


void
on_btn_Ajouter_Nassim_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn_Ajouter_Liste_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobtn_Gauche_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobtn_Centre_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobtn_Droite_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_btn_Afficher_Tree_Liste_clicked     (GtkButton       *button,
                                        gpointer         user_data);
